from __future__ import annotations

import itertools
import sys
from typing import Optional, List, Tuple

from ortools.constraint_solver import pywrapcp
import math

OFF_SHIFT = 0
NIGHT_SHIFT = 1
DAY_SHIFT = 2
EVENING_SHIFT = 3

class CPInstance:
    # BUSINESS parameters
    numWeeks: int
    numDays: int
    numEmployees: int
    numShifts: int
    numIntervalsInDay: int
    minDemandDayShift: list[list[int]]
    minDailyOperation: int
    
    # EMPLOYEE parameters
    minConsecutiveWork: int
    maxDailyWork: int
    minWeeklyWork: int
    maxWeeklyWork: int
    maxConsecutiveNightShift: int
    maxTotalNightShift: int

    # Solver
    solver: pywrapcp.Solver

    def __init__(self, filename: str):
        self.load_from_file(filename)
        self.solver = None
        

    def load_from_file(self, f: str):
        """
        Reads in a file and populates the instance parameters.
        """
        params = {} 
        if not f:
            print("No file provided")
            return
        with open(f, "r") as fl:
            lines = fl.readlines()
            for line in lines:
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                if line.startswith("Business_"):
                    key, value = line.split(":")
                    if key != "Business_minDemandDayShift":
                        params[key] = int(value)
                    else:
                        params[key] = [int(x) for x in value.split()]
                elif line.startswith("Employee_"):
                    key, value = line.split(":")
                    params[key] = int(value)
                
        self.numWeeks = params.get("Business_numWeeks")
        self.numDays = params.get("Business_numDays")
        self.numEmployees = params.get("Business_numEmployees")
        self.numShifts = params.get("Business_numShifts")
        self.numIntervalsInDay = params.get("Business_numIntervalsInDay")
        
        raw = params.get("Business_minDemandDayShift", [])
        self.minDemandDayShift = []
        if raw:
            for i in range(0, self.numDays * self.numShifts, self.numShifts):
                self.minDemandDayShift.append(raw[i : i + self.numShifts])
                
        self.minDailyOperation = params.get("Business_minDailyOperation")
        self.minConsecutiveWork = params.get("Employee_minConsecutiveWork")
        self.maxDailyWork = params.get("Employee_maxDailyWork")
        self.minWeeklyWork = params.get("Employee_minWeeklyWork")
        self.maxWeeklyWork = params.get("Employee_maxWeeklyWork")
        self.maxConsecutiveNightShift = params.get("Employee_maxConsecutiveNigthShift")
        self.maxTotalNightShift = params.get("Employee_maxTotalNigthShift")


    def solve(
        self,
        time_limit_seconds: Optional[float] = None,
    ):
        """
        Employee Scheduling Model 
        """
    
        # TODO: your model goes here
        self.solver = pywrapcp.Solver("Scheduler")
        solver = self.solver
        # variables

        shiftOfEmpDay = [
            [solver.IntVar(0,self.numShifts - 1, f"shifts:{e}.{d}") for d in range(self.numDays)] 
            for e in range(self.numEmployees)
        ]
        durationOfEmpDay = [
            [solver.IntVar([0] + list(range(self.minConsecutiveWork, self.maxDailyWork+1)), f"duration:{e}.{d}") for d in range(self.numDays)] 
            for e in range(self.numEmployees)
        ]

        # linking shifts together with duration of work. it also handles below conditions:
        # employees can't work more than maxDailyWork 
        # employees must work at least minConsecutiveWork 
        # employee can only be assigned to single shift
        for e in range(self.numEmployees):
            for d in range(self.numDays):
                is_off = solver.IsEqualCstVar(shiftOfEmpDay[e][d], OFF_SHIFT)

                # duration == 0 iff shift == 0, else its bounded by 4 and 8
                solver.Add(durationOfEmpDay[e][d] >= self.minConsecutiveWork * (1 - is_off))
                solver.Add(durationOfEmpDay[e][d] <= self.maxDailyWork * (1 - is_off))
        
        # minimum number of employees per shift
        for day in range(self.numDays):
            day_shifts = [shiftOfEmpDay[e][day] for e in range(self.numEmployees)]

            work_shifts = [NIGHT_SHIFT, DAY_SHIFT, EVENING_SHIFT]

            card_min = [self.minDemandDayShift[day][shift] for shift in work_shifts]
            card_max = [self.numEmployees] * len(work_shifts)
            solver.Add(solver.Distribute(day_shifts, work_shifts, card_min, card_max))
        
        # minimum number of hours per day
        for day in range(self.numDays):
            day_hours = [durationOfEmpDay[e][day] for e in range(self.numEmployees)]
            solver.Add(solver.Sum(day_hours) >= self.minDailyOperation)

        # first 4 days different shifts requirement 
        for e in range(self.numEmployees):
            solver.Add(solver.AllDifferent([shiftOfEmpDay[e][d] for d in range(4)]))
        
        # total number of hours an employee works per week must be between minWeeklyWork and maxWeeklyWork
        for employee in range(self.numEmployees):
            for week in range(self.numWeeks):
                start_day = week * 7
                end_day = min(start_day + 7, self.numDays)

                week_hours = [durationOfEmpDay[employee][d] for d in range(start_day,end_day)]
                total_week_hours = solver.Sum(week_hours)

                solver.Add(total_week_hours >= self.minWeeklyWork)
                solver.Add(total_week_hours <= self.maxWeeklyWork)

        # employees can only work maxConsecutiveNightShift nights in a row
        # only need to check 4th and 5th element (specialized for this assignment)
        for e in range(self.numEmployees):
            solver.Add(
                solver.IsEqualCstVar(shiftOfEmpDay[e][3], NIGHT_SHIFT) + 
                solver.IsEqualCstVar(shiftOfEmpDay[e][4], NIGHT_SHIFT)
                <= self.maxConsecutiveNightShift
            )

        # employees can only work maxTotalNightShift
        for employee in range(self.numEmployees):
            night_count = solver.IntVar(0, self.numDays, f"night_count:{employee}")
            solver.Add(solver.Count(shiftOfEmpDay[employee], NIGHT_SHIFT, night_count))
            solver.Add(night_count <= self.maxTotalNightShift)
        
        # HELPER CONSTRAINTS (redundant)
        # detect infeasible shift assignments 
        for day in range(self.numDays):
            off_count = [solver.IsEqualCstVar(shiftOfEmpDay[e][day], OFF_SHIFT)
                        for e in range(self.numEmployees)]
            max_off = self.numEmployees - math.ceil(self.minDailyOperation / self.maxDailyWork)
            solver.Add(solver.Sum(off_count) <= max_off)
                
        # reduces symmetry redundancy (excpet in the case where two shifts are 'equal')
        patternIds = []
        for e in range(self.numEmployees):
            pid = (shiftOfEmpDay[e][0] * 64 +
                shiftOfEmpDay[e][1] * 16 +
                shiftOfEmpDay[e][2] * 4 +
                shiftOfEmpDay[e][3]).Var()
            patternIds.append(pid)

        for e in range(self.numEmployees - 1):
            solver.Add(patternIds[e] <= patternIds[e + 1])
        # for e in range(self.numEmployees - 1):
        #     solver.Add(solver.LexicalLessOrEqual(
        #         shiftOfEmpDay[e],
        #         shiftOfEmpDay[e + 1]
        #     ))

        # solve
        # shift_vars = [
        #     shiftOfEmpDay[e][d]
        #     for e in range(self.numEmployees)
        #     for d in range(self.numDays)
        # ]
        # duration_vars = [
        #     durationOfEmpDay[e][d]
        #     for e in range(self.numEmployees)
        #     for d in range(self.numDays)
        # ]

        # db = solver.Compose([
        #     solver.Phase(
        #         shift_vars,
        #         solver.CHOOSE_MIN_SIZE_LOWEST_MIN,
        #         solver.ASSIGN_MAX_VALUE
        #     ),
        #     solver.Phase(
        #         duration_vars,
        #         solver.CHOOSE_MIN_SIZE_LOWEST_MIN,
        #         solver.ASSIGN_MAX_VALUE,
        #     )
        # ])

        phases = []
        for d in range(self.numDays):
            day_shift_vars = [shiftOfEmpDay[e][d] for e in range(self.numEmployees)]
            day_dur_vars = [durationOfEmpDay[e][d] for e in range(self.numEmployees)]
            phases.append(solver.Phase(day_shift_vars, solver.CHOOSE_MIN_SIZE_LOWEST_MIN, solver.ASSIGN_MIN_VALUE))
            phases.append(solver.Phase(day_dur_vars, solver.CHOOSE_MIN_SIZE_LOWEST_MIN, solver.ASSIGN_MIN_VALUE))
        db = solver.Compose(phases)

        if time_limit_seconds is not None:
            limit = solver.TimeLimit(int(time_limit_seconds * 1000))
            solver.NewSearch(db, [limit])
        else:
            solver.NewSearch(db)

        if self.solver.NextSolution():
            schedule = [
                [(self.shift_to_interval(shiftOfEmpDay[e][d].Value(), durationOfEmpDay[e][d].Value())) for d in range(self.numDays)]
                for e in range(self.numEmployees)
            ]
            return True, self.solver.Failures(), schedule
        else:
            return False, self.solver.Failures(), None

    def shift_to_interval(self,shift, duration):
        if shift == OFF_SHIFT:
            return (-1, -1)
        if shift == NIGHT_SHIFT:
            return (0, duration)
        if shift == DAY_SHIFT:
            return (8, 8 + duration)
        if shift == EVENING_SHIFT:
            return (16, 16 + duration)
        raise ValueError(f"Unknown shift: {shift}")
            
    def prettyPrint(self, numEmployees, numDays, sched):
        """
        Poor man's Gantt chart.
        Displays the employee schedules on the command line. 
        Each row corresponds to a single employee. 
        A "+" refers to a working hour and "." means no work
        The shifts are separated with a "|"
        The days are separated with "||"
        
        This might help you analyze your solutions. 
        
        @param numEmployees the number of employees
        @param numDays the number of days
        @param sched sched[e][d] = (begin, end) hours for employee e on day d
        """
        for e in range(numEmployees):
            print(f"E{e+1}: ", end="")
            if e < 9: print(" ", end="")
            for d in range(numDays):
                begin = sched[e][d][0]
                end = sched[e][d][1]
                for i in range(self.numIntervalsInDay):
                    if i % 8 == 0: print("|", end="")
                    if begin != end and i >= begin and i < end:
                         print("+", end="")
                    else:
                         print(".", end="")
                print("|", end="")
            print(" ")

    def generateVisualizerInput(self, numEmployees, numDays, sched):
        solString = f"{numDays} {numEmployees}\n"
        for d in range(numDays):
            for e in range(numEmployees):
                solString += f"{sched[e][d][0]} {sched[e][d][1]}\n"

        fileName = f"{numDays}_{numEmployees}_sol.txt"
        try:
            with open(fileName, "w") as fl:
                fl.write(solString)
            print(f"File created: {fileName}")
        except IOError as e:
            print(f"An error occured: {e}")

"""
when maxconseuctivenights = 2, we know that night is in first 4, so just check after that
use distribute function to get global counts
use count function instead of converting to 1 and summing up.
- in general, shouldn't be using SAT solver like stuff

- write a verifier to check solution after
- to verify, come up with small instances and enumerate through all solutions
"""
